package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Time;
import java.util.GregorianCalendar;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.*;
import org.junit.jupiter.api.Test;

import Eventi.Evento;
import Eventi.GestioneEvento;
import Eventi.PartitaDiCalcio;
import GestioneExcell.ExcelUtility;
import Versione6.Utente;

public class PartitaDiCalcioTest {

	@Test
	public void GenderError() {
		Utente u=new Utente("User", "Pass", 'M', 18, 0, "18-34", null);
		PartitaDiCalcio p=new PartitaDiCalcio();
		p.setValCampo(p.GENERE, 'F');
		p.aggiornaEta("18-24");
		assertThat(p.accettabile(u.getGenere(), u.getEta()), is(equalTo(false)));
	}
	
	@Test
	public void AgeError() {
		Utente u=new Utente("User", "Pass", 'F', 25, 0, "18-34", null);
		PartitaDiCalcio p=new PartitaDiCalcio();
		p.setValCampo(p.GENERE, 'F');
		p.aggiornaEta("18-24");
		assertThat(p.accettabile(u.getGenere(), u.getEta()), is(equalTo(false)));
	}
	

	@Test
	public void AgeGenderError() {
		Utente u=new Utente("User", "Pass", 'M', 25, 0, "18-34", null);
		PartitaDiCalcio p=new PartitaDiCalcio();
		p.setValCampo(p.GENERE, 'F');
		p.aggiornaEta("18-24");
		assertThat(p.accettabile(u.getGenere(), u.getEta()), is(equalTo(false)));
	}
	
	@Test
	public void NoError() {
		Utente u=new Utente("User", "Pass", 'F', 21, 0, "18-34", null);
		PartitaDiCalcio p=new PartitaDiCalcio();
		p.setValCampo(p.GENERE, 'F');
		p.aggiornaEta("18-24");
		assertThat(p.accettabile(u.getGenere(), u.getEta()), is(equalTo(true)));
	}
}
