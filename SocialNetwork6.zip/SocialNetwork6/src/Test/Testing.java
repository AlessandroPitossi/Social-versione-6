package Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.sql.Time;

import org.junit.jupiter.api.Test;

import Eventi.Evento;
import Eventi.GestioneEvento;
import Eventi.PartitaDiCalcio;
import GestioneExcell.ExcelReader;
import GestioneExcell.ExcelUtility;
import Versione6.Utente;


public class Testing {

	private static Evento inizializzaConIscrizioni(int numIscrizioni, int column) {
		Evento e=new Evento("Evento", "Descrizione", column);
		e.setValCampo(e.TITOLO, "titolo");
		e.setValCampo(e.NUM_PART, numIscrizioni);
		e.setValCampo(e.TERM_ULT_ISCR, mylib.Utility.StringToDate("10/08/3059"));
		e.setValCampo(e.LUOGO, "luogo");
		e.setValCampo(e.DATA, mylib.Utility.StringToDate("10/08/3059"));
		e.setValCampo(e.ORA, Time.valueOf("12:00:00"));
		e.setValCampo(e.DURATA, 3);
		e.setValCampo(e.QUOTA, 12);
		e.setValCampo(e.COMPRESO_QUOTA, "compreso quota");
		e.setValCampo(e.DATA_FIN,  mylib.Utility.StringToDate("10/08/3059"));
		e.setValCampo(e.ORA_FIN, Time.valueOf("12:30:00"));
		e.setValCampo(e.TOLLERANZA_PARTECIPANTI, 0);
		e.setValCampo(e.NOTE, "note");
		e.setValCampo(e.TERMINE_RITIRO_ISCR,  mylib.Utility.StringToDate("10/08/3059"));
		return e;
	}
	
	@Test
	public void numIscrizioniOk() throws IOException {
		File fu=new File("src/Test/FileUtentiTest.xlsx");
		File fe=new File("src/Test/FileEventiTest.xlsx");
		File fue=new File("src/Test/FileUtentiEventiTest.xlsx");
		
		int userColumn=ExcelUtility.getNum(fu, 0);
		Utente u=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		
		int eventColumn=ExcelUtility.getNum(fe, 0);
		Evento e=inizializzaConIscrizioni(5, eventColumn);
		
		ExcelUtility.addUser(u, fu);
		
		GestioneEvento.writeEvent(e, fe, fue, fu);
		
		ExcelUtility.partecipa(e, u, fe, fue, fu);
		
		assertThat(GestioneEvento.getPartAtt(e, fue), is(equalTo(1)));
		
		ExcelReader.removeColumn(fue, 0, eventColumn);
		ExcelReader.removeColumn(fe, 0, eventColumn);
		ExcelReader.removeColumn(fu, 0, userColumn);
	}
	
	@Test
	public void numIscrizioniOkUnaDiMeno() throws IOException {
		File fu=new File("src/Test/FileUtentiTest.xlsx");
		File fe=new File("src/Test/FileEventiTest.xlsx");
		File fue=new File("src/Test/FileUtentiEventiTest.xlsx");
		
		int userColumn=ExcelUtility.getNum(fu, 0);
		Utente u=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u1=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u2=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u3=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		
		int eventColumn=ExcelUtility.getNum(fe, 0);
		Evento e=inizializzaConIscrizioni(5, eventColumn);
		
		ExcelUtility.addUser(u, fu);
		ExcelUtility.addUser(u1, fu);
		ExcelUtility.addUser(u2, fu);
		ExcelUtility.addUser(u3, fu);
		
		GestioneEvento.writeEvent(e, fe, fue, fu);
		
		ExcelUtility.partecipa(e, u, fe, fue, fu);
		ExcelUtility.partecipa(e, u1, fe, fue, fu);
		ExcelUtility.partecipa(e, u2, fe, fue, fu);
		ExcelUtility.partecipa(e, u3, fe, fue, fu);
		
		assertThat(GestioneEvento.getPartAtt(e, fue), is(equalTo(4)));
		
		ExcelReader.removeColumn(fue, 0, eventColumn);
		ExcelReader.removeColumn(fe, 0, eventColumn);
			for(int i=0; i<=userColumn; i++) {
			ExcelReader.removeColumn(fu, 0, i);
		}
	}
	
	@Test
	public void numIscrizioniOkAlLimite() throws IOException {
		File fu=new File("src/Test/FileUtentiTest.xlsx");
		File fe=new File("src/Test/FileEventiTest.xlsx");
		File fue=new File("src/Test/FileUtentiEventiTest.xlsx");
		
		int userColumn=ExcelUtility.getNum(fu, 0);
		Utente u=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u1=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u2=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u3=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u4=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		
		int eventColumn=ExcelUtility.getNum(fe, 0);
		Evento e=inizializzaConIscrizioni(5, eventColumn);
		
		ExcelUtility.addUser(u, fu);
		ExcelUtility.addUser(u1, fu);
		ExcelUtility.addUser(u2, fu);
		ExcelUtility.addUser(u3, fu);
		ExcelUtility.addUser(u4, fu);
		
		GestioneEvento.writeEvent(e, fe, fue, fu);
		
		ExcelUtility.partecipa(e, u, fe, fue, fu);
		ExcelUtility.partecipa(e, u1, fe, fue, fu);
		ExcelUtility.partecipa(e, u2, fe, fue, fu);
		ExcelUtility.partecipa(e, u3, fe, fue, fu);
		ExcelUtility.partecipa(e, u4, fe, fue, fu);
		
		assertThat(GestioneEvento.getPartAtt(e, fue), is(equalTo(5)));
		
		ExcelReader.removeColumn(fue, 0, eventColumn);
		ExcelReader.removeColumn(fe, 0, eventColumn);
			for(int i=0; i<=userColumn; i++) {
			ExcelReader.removeColumn(fu, 0, i);
		}
	}
	
	@Test
	public void numIscrizioniUnaDiPi�() throws IOException {
		File fu=new File("src/Test/FileUtentiTest.xlsx");
		File fe=new File("src/Test/FileEventiTest.xlsx");
		File fue=new File("src/Test/FileUtentiEventiTest.xlsx");
		
		int userColumn=ExcelUtility.getNum(fu, 0);
		Utente u=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u1=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u2=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u3=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u4=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		userColumn++;
		Utente u5=new Utente("id"+userColumn, "pass", 'M', 18, userColumn, "src/Test/FileUser.xlsx", "18-24", null);
		
		int eventColumn=ExcelUtility.getNum(fe, 0);
		Evento e=inizializzaConIscrizioni(5, eventColumn);
		
		ExcelUtility.addUser(u, fu);
		ExcelUtility.addUser(u1, fu);
		ExcelUtility.addUser(u2, fu);
		ExcelUtility.addUser(u3, fu);
		ExcelUtility.addUser(u4, fu);
		ExcelUtility.addUser(u5, fu);
		
		GestioneEvento.writeEvent(e, fe, fue, fu);
		
		ExcelUtility.partecipa(e, u, fe, fue, fu);
		ExcelUtility.partecipa(e, u1, fe, fue, fu);
		ExcelUtility.partecipa(e, u2, fe, fue, fu);
		ExcelUtility.partecipa(e, u3, fe, fue, fu);
		ExcelUtility.partecipa(e, u4, fe, fue, fu);
		ExcelUtility.partecipa(e, u5, fe, fue, fu);
		
		assertThat(GestioneEvento.getPartAtt(e, fue), is(equalTo(5)));
		
		assertThat(ExcelUtility.iscritto(e, u5, fue, 0), is(equalTo(false)));
		
		ExcelReader.removeColumn(fue, 0, eventColumn);
 		ExcelReader.removeColumn(fe, 0, eventColumn);
		for(int i=0; i<=userColumn; i++) {
			ExcelReader.removeColumn(fu, 0, i);
		}
	}
}
