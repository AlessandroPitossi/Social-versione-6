package Versione6;

import Interfacce.GestioneMenu;
import Interfacce.Menu;

public class Main {

	public static void main(String[] args) {
		Utente u=GestioneMenu.menuLogIn();
		Menu.menuHome(u);
	}
}