package Interfacce;

import java.io.File;
import java.util.ArrayList;

import Eventi.Bacheca;
import Eventi.Concerto;
import Eventi.Evento;
import Eventi.GestioneEvento;
import Eventi.Notifica;
import Eventi.PartitaDiCalcio;
import GestioneExcell.ExcelReader;
import GestioneExcell.ExcelUtility;
import Stati.Aperto;
import Versione6.Utente;
import Versione6.Utility;
import mylib.BelleStringhe;
import mylib.InputDati;
import mylib.MyMenu;

public class GestioneMenu {

	private static final String LOG_IN="Login";
	private static final String VOCI_LOG_IN[]= {"Accedi", "Registrati"};
	private static final String MSG_USER="Inserisci il tuo id utente: ";
	private static final String MSG_PASSWORD="Inserisci la tua password: ";
	private static final String MSG_ERR_LOG_IN="Utente o password errati";
	private static final String BACHECA="Bacheca";
	private static final String SCELTA_EVENTO="\nScegli l'evento a cui iscriverti, 0 per uscire";
	private static final String BACHECA_VUOTA="\nNon ci sono eventi pubblicati in bacheca\n";
	private static final String NOTIFICHE="Sezione Notifiche";
	private static final String SCELTA_NOTIFICA="\nScegli la notifica da vedere, 0 per uscire";
	private static final String NO_NOTIFICHE="\nNon hai nessuna notifica\n";
	private static final String CANCELLAZIONE="Vuoi cancellare la notifica?";
	private static final String	PARTECIPAZIONE="Vuoi partecipare a questo evento?";
	private static final String	ERRORE_EVENTO="\nCi discpiace, ma tale evento non � pi� presente in bacheca\n";
	private static final String	NO_INVITABILI="\nNon ci sono utenti che puoi invitare, per poter invitare qualcuno quest'ultimo deve aver partecipato, in passato, ad un evento proposto da te della stessa categoria che vuoi proporre\n";
	private static final String	INVITI="Invita qualcuno";
	private static final String	INVITO_ANCORA="Vuoi invitare qualcun'altro?";
	private static final String CHI_INVITARE="Chi vuoi invitare?";
	private static final String INVITA_TUTTI="Vuoi invitare tutti?";
	private static final String	CONSENSO_CATEGORIE="Vuoi inserire le categorie d'interesse?";
	private static final String	MSG_ID="Inserisci il nomignolo che vuoi (attenzione, non sar� modificabile in futuro):";
	private static final String	DOPPIONE="\nAttenzione: nomignolo gi� utilizzato da qualcun'altro, scegline un altro";
	private static final String	CONSENSO_FASCIA_ETA="Vuoi inserire la fascia d'et� in cui ricadi?";
	private static final String CONSENSO="Confermi di voler registrarti con questo profilo?";
	private static final String ID="Id:";
	private static final String PASSWORD="Password:";
	private static final String OP_ANNULLATA="\nOperazione annullata\n";
	private static final String MSG_GENDER="Sei maschio (M) o femmina (F)?";
	private static final String CHAR_AMMISSIBILI="MF";
	private static final String MSG_ETA="Inserisci la tua et� (minimo 14 anni, massimo 130)";
	public static final int MIN=14;
	public static final int MAX=130;
	private static final String NO_ISCRIZIONI="\nNon sei iscritto a nessun evento\n";
	private static final String ISCRIZIONI="Iscrizioni";
	private static final String CANCELLA_ISCRIZIONE="\nVuoi cancellare l'iscrizione ad uno di questi eventi?\n";
	private static final String SCELTA_CANCELLAZIONE="\nQuale iscrizione vuoi annullare?\n";
	private static final String CANCELLAZIONE_AVVENUTA="\nCancellazione effettuata con successo\n";
	private static final String NO_CANCELLAZIONE_CREATORE="\nSei il creatore dell'evento, non puoi disiscriverti\n";
	public static final int LARGHEZZA=50;
	private static final String CREAZIONI="Eventi aperti che hai proposto";
	private static final String NO_CREAZIONI="\nNon hai proposto alcun evento attualmente aperto\n";
	private static final String CANCELLA_PROPOSTA="Vuoi eliminare una delle proposte fatte?";
	private static final String SCELTA_CANCELLAZIONE_PROP="Quale proposta vuoi eliminare?";
	private static final String SUPERATO_TERM_RITIRO="\nAttenzione: superato il termine per il ritiro ";
	private static final String PROPOSTA="della proposta scelta\n";
	private static final String ISCRIZIONE="dell'iscrizione scelta\n";
	private static final String CANCELLAZIONE_ANNULLATA="\nCancellazione annullata\n";
	private static final String CATEGORIE_INTERESSE="Seleziona le categorie che ti interessano";	
	private static final String	ERRORE_FASCIA="\nAttenzione: la fascia d'et� che inserisci deve comprendere la tua et�\n";
	private static final String	SCEGLI_CATEGORIA="Quale categoria ti interessa?";
	private static final String[] CAT_ESISTENTI= {PartitaDiCalcio.NOME, Concerto.NOME};
	private static final String NO_MORE_CATEGORIES="Non ci sono ulteriori categorie da poter aggiungere";
	private static final String SCEGLI_RIMOZIONE="Quale categoria vuoi rimuovere?";
	private static final String CATEGORIE_RIMOZIONE="Seleziona le categorie che vuoi rimuovere";
	private static final String NO_CATEGORIES="Non hai alcuna categoria da poter rimuovere";
	private static final int FIRST_PAGE=0;
	
	public static Utente menuLogIn() {
		ExcelUtility.aggiornamenti();
		ExcelUtility.modificaStatiEventi();
		MyMenu m=new MyMenu(LOG_IN, VOCI_LOG_IN);
		boolean finito=false;
		Utente u=null;
		do {
			int i=m.scegliSenzaEsci();
			switch(i) {
				case 1: u=accediMenuLogIn();
						break;
				case 2: u=registratiMenuLogIn();
						break;
			}				
			finito=(u!=null);
		}while(!finito);
		return u;
	}
	
	private static Utente registratiMenuLogIn() {
		ArrayList<String> categorie=new ArrayList<>();
		Utente u=null;
		String name;
		char gender;
		int eta;
		String fascia=ExcelUtility.NO_FASCIA;
		name=inserisciNome();
		boolean consenso;
		gender=InputDati.leggiUpperChar(MSG_GENDER, CHAR_AMMISSIBILI);
		eta=InputDati.leggiIntero(MSG_ETA, MIN, MAX);
		consenso=InputDati.yesOrNo(CONSENSO_FASCIA_ETA);
		if(consenso) {
			fascia=mylib.Utility.inserisciFascia(eta, MIN, MAX, ERRORE_FASCIA);
		}
		consenso=InputDati.yesOrNo(CONSENSO_CATEGORIE);
		if(consenso) {
			categorie=Menu.menuCategorie(CAT_ESISTENTI, SCEGLI_CATEGORIA, CATEGORIE_INTERESSE);
		}
		consenso=InputDati.yesOrNo(CONSENSO);
		if(consenso) {
		u=Utente.createUtente(name, gender, eta, fascia, categorie);
		System.out.println(ID+u.getId()+" "+PASSWORD+u.getPassword());
		}
		else System.out.println(OP_ANNULLATA);
		return u;
	}
	
	public static String inserisciNome() {
		String name;
		boolean accettabile;
		ArrayList<String>names=new ArrayList<>();
		ExcelUtility.takeIds(names);
		do {
			name=InputDati.leggiStringaNonVuota(MSG_ID);
			accettabile=mylib.Utility.accettabile(names, name, DOPPIONE);
		}while(!accettabile);
		return name;
	}
	
	private static Utente accediMenuLogIn() {
		Utente u=null;
		ArrayList<String> ids=new ArrayList<>();
		ArrayList<String> passwords=new ArrayList<>();
		String id=InputDati.leggiStringaNonVuota(MSG_USER);
		String password=InputDati.leggiStringaNonVuota(MSG_PASSWORD);
		ExcelUtility.takeIds(ids);
		ExcelUtility.takePasswords(passwords);
		if (Utility.contenuto(ids, id) && Utility.contenuto(passwords, password)) {
			u=ExcelUtility.takeUser(id);
		}
		else System.out.println(BelleStringhe.rigaIsolata(MSG_ERR_LOG_IN));
		return u;
	}
	
	public static void menuBacheca(Utente u) {
		Bacheca b=Bacheca.getInstance();
		ExcelUtility.modificaStatiEventi();
		ArrayList<Integer> colonne=new ArrayList<>();
		ArrayList<String> eventi=b.mostraEventi(colonne);
		if(eventi.size()==0) System.out.println(BACHECA_VUOTA);
		else{
			MyMenu m=new MyMenu(BACHECA, eventi);
			boolean finito=false;
			do {
				int i=m.scegli(SCELTA_EVENTO);
				switch(i) {
					case 0: finito=true;
							break;
					default: finito=sceltaEvento(colonne, i, u);
				}
			}while(!finito);
		}
	}
	
	public static boolean sceltaEvento(ArrayList<Integer> colonne, int scelta, Utente u) {
		ArrayList<String> column=new ArrayList<>();
		int j=colonne.get(scelta-1);
		column=ExcelReader.takeColumn(GestioneEvento.FILE_EV, j, GestioneEvento.FIRST_PAGE);
		String nome=column.get(GestioneEvento.EVENT_NOME_ROW);
		Evento e=Utility.getEvento(nome, j);
		return partecipa(e, u);
	}
	
	/*
	 * Precondizioni: sia l'utente che l'evento passati devono essere registrati all'interno dei file
	 */
	private static boolean partecipa(Evento e, Utente u) {
		return ExcelUtility.partecipa(e, u);
	}
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void menuNotifiche(Utente u) {
		ExcelUtility.modificaStatiEventi();
		ArrayList<Notifica> notifiche=ExcelUtility.visualizzaElencoNotifiche(u);
		ArrayList<String> titoli=new ArrayList<>();
		if(notifiche.size()==0)	System.out.println(NO_NOTIFICHE);
		else {
			boolean finito=false;
			for(int i=0; i<notifiche.size(); i++) {
				titoli.add(notifiche.get(i).mostraTitolo());
			}
			do {
				MyMenu m=new MyMenu(NOTIFICHE, titoli);
				int i=m.scegli(SCELTA_NOTIFICA);
				switch(i) {
				case 0: finito=true;
						break;
				default:int j=i-1;
						notifiche.get(j).mostra();
						ExcelUtility.NotifyRead(notifiche.get(j), notifiche.size()-i, u);
						if(notifiche.get(j).getInvito()) {
							boolean partecipa=InputDati.yesOrNo(PARTECIPAZIONE);
							if(partecipa) {
								int colonna=notifiche.get(j).getEventColumn();
								String nome=ExcelUtility.takeNomeEvento(notifiche.get(j).getEventColumn());
								Evento e=Utility.getEvento(nome, colonna);
								if(!(e.getStato() instanceof Aperto)) System.out.println(ERRORE_EVENTO);
								else partecipa(e, u);
							}
						}
						titoli.set(j, notifiche.get(j).mostraTitolo());
						boolean ok=InputDati.yesOrNo(CANCELLAZIONE);
						if(ok) {
							ExcelReader.removeRow(new File(u.getFileName()), notifiche.size()-i, GestioneEvento.FIRST_PAGE);
							notifiche.remove(j);
							titoli.remove(j);
						} 
					}				
			}while(!finito);
		}
	}
	

	/*
	 * Precondizioni: l'evento passato deve essere registrato all'interno dei file
	 * 				  l'arrayList passato contiene gli utenti che possono essere invitati all'evento passato
	 */
	public static void invita(ArrayList<Utente> invitabili, Evento e) {
		boolean finito=false;
		ArrayList<Utente> invitati=new ArrayList<Utente>();
		ArrayList<String> nomiInvitabili=new ArrayList<>();
		for(int i=0; i<invitabili.size(); i++) {
			nomiInvitabili.add(invitabili.get(i).getId());
		}
		MyMenu m=new MyMenu(INVITI, nomiInvitabili);
		m.stampaMenuSenzaEsci();
		if(invitabili.size()==0) {
			System.out.println(BelleStringhe.aCapo(NO_INVITABILI, Menu.LARGHEZZA));
			finito=true;
		}
		else {
			boolean tutti=InputDati.yesOrNo(INVITA_TUTTI);
			if(tutti) {
				invitati=invitabili;
				finito=true;
			}
			else{
				do {
						int i=m.scegli(CHI_INVITARE);
						switch(i) {
							case 0: finito=true;
									break;
							default:invitati.add(invitabili.get(i-1));
									invitabili.remove(i-1);
									nomiInvitabili.remove(i-1);
									finito=!InputDati.yesOrNo(INVITO_ANCORA);
									break;
						}
				}while(!finito);
			}
		}
		if(invitati.size()!=0) {
			Notifica n=Interfaces.invito(e);
			ExcelUtility.writeNotify(n, invitati);
		}
	}
	/*
	 * Postcondizioni: nei file degli utenti selezionati saranno presenti degli inviti per l'evento passato
	 */
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void addCategoriaMenuProfilo(Utente u) {
		ArrayList<String> categorie=null;
		categorie=ExcelUtility.getCategorie(u);
		if(categorie.size()==CAT_ESISTENTI.length) {
			System.out.println(NO_MORE_CATEGORIES);
		}
		else{
			ArrayList<String> catEsistenti=new ArrayList<>();
			for(int j=0; j<CAT_ESISTENTI.length; j++) {
				catEsistenti.add(CAT_ESISTENTI[j]);
			}
			for(int j=0; j<categorie.size(); j++) {
				for(int k=0; k<catEsistenti.size(); k++) {
					if(catEsistenti.get(k).equals(categorie.get(j))) catEsistenti.remove(k);
				}
			}
			String[] useless= {};
			String[] rimanenti=catEsistenti.toArray(useless);
			catEsistenti=Menu.menuCategorie(rimanenti, SCEGLI_CATEGORIA, CATEGORIE_INTERESSE);
			for(int j=0; j<catEsistenti.size(); j++) {
				u.addCategoria(catEsistenti.get(j));
			}
		}
	}
	/*
	 * Postcondizioni: il numero di categorie d'interesse associate all'utente � >= a quello precedente all'invocazione del metodo
	 */
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void removeCategoriaMenuProfilo(Utente u) {
		ArrayList<String> categorie=null;
		categorie=ExcelUtility.getCategorie(u);
		if(categorie.size()==0) {
			System.out.println(NO_CATEGORIES);
		}
		else {
			ArrayList<String> catUtente=new ArrayList<>();
			String[] useless= {};
			String[] rimanenti=categorie.toArray(useless);
			catUtente=Menu.menuCategorie(rimanenti, SCEGLI_RIMOZIONE, CATEGORIE_RIMOZIONE);
			for(int j=0; j<catUtente.size(); j++) {
				int k=u.getCategorie().indexOf(catUtente.get(j));
				u.removeCategoria(k);
			}
		}
	}
	/*
	 * Postcondizioni: il numero di categorie d'interesse associate all'utente � <= a quello precedente all'invocazione del metodo
	 */
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void menuProposteFatte(Utente u) {
		 ArrayList<Evento> eventi=ExcelUtility.getEventiUtente(u);
		 ArrayList<Evento> eventiCreati=new ArrayList<>();
		 for(int i=0; i<eventi.size(); i++) {
			 if(eventi.get(i).creatore(u)) {
				 eventiCreati.add(eventi.get(i));
			 }
		 }
		 if(eventiCreati.size()==0) System.out.println(NO_CREAZIONI);
		 else {
			ArrayList<String> eventiUtente=new ArrayList<>();
			for(int i=0; i<eventiCreati.size(); i++) {
			eventiUtente.add(eventiCreati.get(i).mostraEv());
			}
			MyMenu menu=new MyMenu(CREAZIONI, eventiUtente);
			menu.stampaMenuSenzaEsci();
			boolean cancella=InputDati.yesOrNo(CANCELLA_PROPOSTA);
			if(cancella) {
				int i=menu.scegli(SCELTA_CANCELLAZIONE_PROP);
				if(i!=0) {
					Evento eventoScelto=eventi.get(i-1);
					if(!eventoScelto.ritirabile()) {
						System.out.println(SUPERATO_TERM_RITIRO+PROPOSTA);
						System.out.println(CANCELLAZIONE_ANNULLATA);
					}
					else {
						GestioneEvento.ritiraEvento(eventoScelto);
					}
				}
			}
		 }
	}
	/*
	 * Postcondizioni: il numero di proposte aperte fatte dall'utente � <= a quello precedente all'invocazione del metodo
	 * 				   in caso di cancellazione di una proposta, sar� presente una nuova notifica nei file personali di tutti gli 
	 * 				   utenti iscritti all'evento passato
	 */
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void menuIscrizioni(Utente u) {
		 ArrayList<Evento> eventi=ExcelUtility.getEventiUtente(u);
			if(eventi.size()==0) System.out.println(NO_ISCRIZIONI);
			else {
				ArrayList<String> eventiUtente=new ArrayList<>();
				for(int i=0; i<eventi.size(); i++) {
					eventiUtente.add(eventi.get(i).mostraEv());
				}
				MyMenu menu=new MyMenu(ISCRIZIONI, eventiUtente);
				menu.stampaMenuSenzaEsci();
				boolean cancella=InputDati.yesOrNo(CANCELLA_ISCRIZIONE);
				if(cancella) {
					int i=menu.scegli(SCELTA_CANCELLAZIONE);
					if(i!=0) {
						Evento eventoScelto=eventi.get(i-1);
						if(eventoScelto.creatore(u)) {
							System.out.println(NO_CANCELLAZIONE_CREATORE);
						}
						else { 
							if(!eventoScelto.ritirabile()) System.out.println(SUPERATO_TERM_RITIRO+ISCRIZIONE);
							else{
								int j=Utility.getNomiUtenti(GestioneEvento.getUtenti(eventoScelto)).indexOf(u.getId());
								ExcelReader.removeCell(j, eventoScelto.getColumn(), GestioneEvento.FILE_UT_EV, FIRST_PAGE);
								System.out.println(CANCELLAZIONE_AVVENUTA);
								System.out.println(CANCELLAZIONE_ANNULLATA);
							}
						}
					}
				}
			}
	}
	/*
	 * Postcondizioni: il numero di iscrizioni dell'utente � <= a quello precedente all'invocazione del metodo
	 */
}
