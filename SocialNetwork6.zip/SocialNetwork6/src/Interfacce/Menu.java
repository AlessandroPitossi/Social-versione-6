package Interfacce;

import java.util.ArrayList;

import Eventi.Concerto;
import Eventi.Evento;
import Eventi.PartitaDiCalcio;
import GestioneExcell.ExcelUtility;
import Versione6.Utente;
import Versione6.Utility;
import mylib.BelleStringhe;
import mylib.InputDati;
import mylib.MyMenu;

public class Menu {
	private static final String MSG_ETA="Inserisci la tua et� (minimo 14 anni, massimo 130)";
	public static final int MIN=14;
	public static final int MAX=130;
	
	private static final String BENVENUTO="Benvenuto nella home page";
	private static final String HOME_PAGE="Home Page";
	private static final String VOCI_HOME_PAGE[]= {"Mostra categorie", "Mostra notifiche", "Mostra Bacheca", "Proponi Evento", 
			"Mostra eventi a cui sei iscritto", "Mostra eventi che hai proposto", "Mostra profilo personale"};
	private static final String EVENTI="Di quale evento vuoi creare una proposta?";
	private static final String SCEGLI_EVENTO="\nScegli la categoria di evento da creare >";
	public static final int LARGHEZZA=50;
	private static final String ARRIVEDERCI="Arrivederci, torna a visitare il nostro social!";
	private static final String	ERRORE_FASCIA="\nAttenzione: la fascia d'et� che inserisci deve comprendere la tua et�\n";
	private static final String	CONTINUA="Vuoi ripetere l'operazione?";
	private static final String PROFILO="Profilo";
	private static final String MODIFICA="Vuoi modificare una delle voci?";
	private static final String VOCE_MODIFICA="Modifica";
	private static final String[] POSSIBILI_MODIFICHE= {"Modifica et�", "Modifica fascia d'et�", "Aggiungi categorie d'interesse", "Rimuovi categorie d'interesse"};
	private static final String MSG_MODIFICA="Quale voce vuoi modificare?";
	private static final String NECESSITA_MODIFICA_FASCIA="L'et� che hai inserito non rientra pi� nella fascia d'et� che era impostata, � necessario modificare anche quest'ultima affinch� sia compatibile";
	private static final String MODIFICARE_ANCORA="Vuoi modificare qualcos'altro?";
	private static final String CONFERMA="Confermi?";
	private static final String NECESSITA_MODIFICA_ETA="La fascia d'et� che hai inserito non � pi� compatibile con l'et� che era impostata, � necessario modificare anche quest'ultima affinch� sia compatibile";
	private static final String ERRORE_ETA_FASCIA="\nAttenzione: l'et� che inserisci deve rientrare nella fascia d'et� impostata precedentemente, cio� ";
	private static final String MSG_FASCIA="Inserisci la fascia d'et�";
	private static final String[] CAT_ESISTENTI= {PartitaDiCalcio.NOME, Concerto.NOME};
	
	public static ArrayList<String> menuCategorie(String[] categories, String msgScelta, String titoloMenu) {
		ArrayList<String> categorie=new ArrayList<>();
		ArrayList<String> voci=new ArrayList<>();
		for(int i=0; i<categories.length; i++) {
			voci.add(categories[i]);
		}
		MyMenu m=new MyMenu(titoloMenu, voci);//CATEGORIE_INTERESSE
		boolean finito=false;
		do {
			int i=m.scegli(msgScelta);//SCEGLI_CATEGORIA
			if(i==0) finito=true;
			else{
				categorie.add(voci.get(i-1));
				voci.remove(i-1);
				m=new MyMenu(titoloMenu, voci);
				if(voci.size()==0) finito=true;
				else finito=!InputDati.yesOrNo(CONTINUA);
			}
		}while(!finito);
		return categorie;
	}
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void menuBacheca(Utente u) {
		GestioneMenu.menuBacheca(u);
	}
	
	public static void menuNotifiche(Utente u) {
		GestioneMenu.menuNotifiche(u);
	}
	
	public static void menuProposteFatte(Utente u) {
		GestioneMenu.menuProposteFatte(u);
	}
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	public static void menuHome(Utente u) {
		MyMenu m=new MyMenu(HOME_PAGE, VOCI_HOME_PAGE);
		boolean finito=false;
		System.out.println(BelleStringhe.rigaIsolata(BelleStringhe.incornicia(BENVENUTO)));
		do {
			int i=m.scegli();
			switch(i) {
				case 1: mostraCategorie();
						break;
				case 2: menuNotifiche(u);
					    break;
				case 3: menuBacheca(u);
					    break;
				case 4:	Evento e=menuSceltaEvento();
						ExcelUtility.createEvento(e, u);
					    break;
				case 5:	menuIscrizioni(u);
						break;
				case 6: menuProposteFatte(u);
						break;
				case 7: menuProfilo(u);
						break;
				case 0: System.out.println(BelleStringhe.rigaIsolata(BelleStringhe.incornicia(ARRIVEDERCI)));
					    finito=true;
						break;
			}				
		}while(!finito);
	}
	
	private static void mostraCategorie() {
		PartitaDiCalcio p=new PartitaDiCalcio();
		Concerto c=new Concerto();
		Utility.mostraCategorie(p);
		Utility.mostraCategorie(c);
	}
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	private static void menuProfilo(Utente u) {
		System.out.println(BelleStringhe.incornicia(PROFILO));
		System.out.println(Interfaces.getProfilo(u));
		boolean ok=InputDati.yesOrNo(MODIFICA);
		if(ok) {
			boolean finito=false;
			do {
				MyMenu m=new MyMenu(VOCE_MODIFICA, POSSIBILI_MODIFICHE);
				int i=m.scegli(MSG_MODIFICA);				
				switch(i) {
					case 1:	modificaEtaMenuProfilo(u);
							break;
					case 2: modificaFasciaMenuProfilo(u);
							break;
					case 3:	GestioneMenu.addCategoriaMenuProfilo(u);
							break;
					case 4: GestioneMenu.removeCategoriaMenuProfilo(u);
							break;
					case 0: finito=true;
						    break;
				}
				finito=!InputDati.yesOrNo(MODIFICARE_ANCORA);
			}while(!finito);
		}
	}
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	private static void modificaEtaMenuProfilo(Utente u) {
		boolean consenso=false;
		int eta;
		String fascia="";
		do{
			eta=InputDati.leggiIntero(MSG_ETA, MIN, MAX);
			consenso=InputDati.yesOrNo(CONFERMA);
		}while(!consenso);
		u.setEta(eta);
		if(u.getFascia()!=null&&u.getFascia()!="") {
			if(!Utility.etaContenuta(u.getFascia(), eta)) {
				System.out.println(BelleStringhe.aCapo(NECESSITA_MODIFICA_FASCIA, LARGHEZZA));
				fascia=mylib.Utility.inserisciFascia(eta, MIN, MAX, ERRORE_FASCIA);
				u.setFascia(fascia);
			}
		}
	}
	/*
	 * Postcondizioni: l'et� (e in caso di necessit� anche la fascia d'et�) dell'utente passato risultano modificate con quelle inserite
	 * 				   e le modifiche sono registrate su file
	 */
	
	/*
	 * Precondizioni: l'utente passato deve essere registrato all'interno dei file
	 */
	private static void modificaFasciaMenuProfilo(Utente u) {
		boolean consenso=false;
		int eta;
		String fascia="";
		do{
			fascia=InputDati.leggiFasciaEta(MSG_FASCIA, MIN, MAX);
			consenso=InputDati.yesOrNo(CONFERMA);
		}while(!consenso);
		u.setFascia(fascia);
		if(!Utility.etaContenuta(fascia, u.getEta())) {
			System.out.println(BelleStringhe.aCapo(NECESSITA_MODIFICA_ETA, LARGHEZZA));
			do{
				eta=InputDati.leggiIntero(MSG_ETA, MIN, MAX);
				if(!Utility.etaContenuta(fascia, eta)) System.out.println(ERRORE_ETA_FASCIA+fascia);
			}while(!Utility.etaContenuta(fascia, eta));
			u.setEta(eta);
		}
	}
	/*
	 * Postcondizioni: la fascia d'et� (e in caso di necessit� anche l'et�) dell'utente passato risultano modificate con quelle inserite
	 * 				   e le modifiche sono registrate su file
	 */
	
	
	private static void menuIscrizioni(Utente u) {
		GestioneMenu.menuIscrizioni(u);
	}
	
	public static Evento menuSceltaEvento() {
		MyMenu m=new MyMenu(EVENTI, CAT_ESISTENTI);
		boolean finito=false;
		Evento e=null;
		do {
			int i=m.scegliSenzaEsci(SCEGLI_EVENTO);
			switch(i) {
				case 1: e=new PartitaDiCalcio();
						finito=true;
						break;
				case 2: e=new Concerto();
						finito=true;
						break;
			}
		}while(!finito);
		return e;
	}
}
