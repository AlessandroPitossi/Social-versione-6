package Eventi;

import java.util.ArrayList;

import GestioneExcell.ExcelReader;
import Versione6.Utente;

public class GestionePartitaDiCalcio extends GestioneEvento{

	public static final int EVENT_GENERE_ROW=NUM_CAMPI+1;
	public static final int EVENT_FASCIA_ROW=NUM_CAMPI+2;
	
	public static void setValoriPartita(PartitaDiCalcio p, int colonna) {
		ArrayList<String> column=ExcelReader.takeColumn(FILE_EV, colonna, FIRST_PAGE);
		p.setValCampo(PartitaDiCalcio.GENERE, column.get(EVENT_GENERE_ROW).charAt(0));
		p.setValCampo(PartitaDiCalcio.FASCIA_ETA, column.get(EVENT_FASCIA_ROW));
	}

	public static boolean addUtente(Utente u, PartitaDiCalcio p) {
		boolean ok=p.accettabile(u.getGenere(), u.getEta());
		if(ok) {
			return GestioneEvento.addUtente(u, p);
		}
		else return false;
	}
}
