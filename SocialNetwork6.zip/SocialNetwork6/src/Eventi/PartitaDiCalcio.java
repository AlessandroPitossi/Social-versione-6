package Eventi;

import java.util.ArrayList;

import GestioneExcell.ExcelReader;
import Interfacce.Interfaces;
import Interfacce.Menu;
import Versione6.Utente;
import Versione6.Utility;
import mylib.*;

public class PartitaDiCalcio extends Evento implements EventInterface{

	private static final boolean OBBLIGATORIO=true;
	public static final String NOME="Partita di calcio";
	private static final String DESCRIZIONE="Organizza una partita di calcio insieme ai tuoi amici";
	public static final String GENERE="Genere";
	private static final String DESCR_GENERE="Il genere (maschile o femminile) dei giocatori";
	public static final String FASCIA_ETA="Fascia d'et�";
	private static final String DESCR_FASCIA_ETA="Estremo inferiore e superiore di et� ammissibile dei giocatori";
	private static final String ERRORE_ETA="\nAttenzione:La fascia di et� dell'evento che stai creando deve comprendere la tua et�\n";
	private static final String	ERRORE_GENERE="\nAttenzione: questo evento � destinato unicamente ";
	private static final String ERRORE_ETA_UTENTE="\nAttenzione: questo evento � destinato a coloro con et� ";
	private static final String UOMINI="agli uomini\n";
	private static final String DONNE="alle donne\n";
	private static final char MASCHIO='M';
	private Campo <Character> genere=new Campo<>(GENERE, DESCR_GENERE, OBBLIGATORIO);
	private Campo <String> fasciaEta=new Campo<>(FASCIA_ETA, DESCR_FASCIA_ETA, OBBLIGATORIO);
	private int etaMin;
	private int etaMax;
	private ArrayList <Integer> eta=new ArrayList<>();
	
	public PartitaDiCalcio () {
		super(NOME, DESCRIZIONE);
		addCampo(genere);
		addCampo(fasciaEta);
	}
	
	public PartitaDiCalcio (int colonna) {
		super(colonna);
		addCampo(genere);
		addCampo(fasciaEta);
		GestionePartitaDiCalcio.setValoriPartita(this, colonna);
		Utility.prendiEta(fasciaEta.getValore(), eta);
		setEtaMin(eta.get(0));
		setEtaMax(eta.get(1));
	}
	
	private void calcEta() {
		String fascia= fasciaEta.getValore();
		Utility.prendiEta(fascia, eta);
		setEtaMin(eta.get(0));
		setEtaMax(eta.get(1));
	}
	
	public void aggiornaEta(String valFascia) {
		setValCampo(FASCIA_ETA, valFascia);
		calcEta();
	}
	
	public void inizializza(Campo c, Utente u) {
		if(c.getNome().equals(FASCIA_ETA)) {
			boolean ok=false;
			do{
				aggiornaEta(InputDati.leggiFasciaEta(MESSAGGIO_CAMPO+c.getNome()+FINE_MESSAGGIO_CAMPO, Menu.MIN, Menu.MAX));
				if(etaMin>u.getEta()||etaMax<u.getEta()) {
					System.out.println(ERRORE_ETA);
				}
				else ok=true;
			}while(!ok);
		}
		else if (c.getNome().equals(GENERE)) setGenere(u.getGenere());
		else super.inizializza(c, u);
	}

	public boolean accettabile(char genere, int eta) {
		if(genere!=getGenere()) {
			System.out.print(ERRORE_GENERE);
			if(getGenere()==MASCHIO) System.out.println(UOMINI);
			else System.out.println(DONNE); 
			return false;
		}
		else {
			if(eta<etaMin||eta>etaMax) {
				System.out.println(ERRORE_ETA_UTENTE+etaMin+"-"+etaMax);
				return false;
			}
		}
		return true;
	}
	
	public boolean addUtente(Utente u) {
		return GestionePartitaDiCalcio.addUtente(u, this);
	}
	
	public String mostraEv() {
			String s=Interfaces.mostraEvento(this);
			s+=PartitaDiCalcio.GENERE+": "+getGenere()+"\n";
			s+=PartitaDiCalcio.FASCIA_ETA+": "+getFascia()+"\n";
			return s;
	}
	
	public int getEtaMin() {
		return etaMin;
	}

	public void setEtaMin(int etaMin) {
		this.etaMin = etaMin;
	}

	public int getEtaMax() {
		return etaMax;
	}

	public void setEtaMax(int etaMax) {
		this.etaMax = etaMax;
	}
	
	public void setGenere(char c) {
		setValCampo(GENERE, c);
	}
	
	public char getGenere() {
		return genere.getValore();
	}
	
	public String getFascia() {
		return fasciaEta.getValore();
	}
}
	
