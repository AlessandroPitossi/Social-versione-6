package Eventi;

import java.util.ArrayList;

import GestioneExcell.ExcelReader;
import Interfacce.Interfaces;
import Versione6.Utente;
import Versione6.Utility;
import mylib.InputDati;

public class Concerto extends Evento implements EventInterface{

	private static final boolean OBBLIGATORIO=true;
	private static final boolean FACOLTATIVO=false;
	public static final String NOME="Concerto";
	private static final String DESCRIZIONE="Organizza insieme ad altri utenti una trasferta per assistere un concerto";
	public static final String ARTISTA="Artista";
	private static final String DESCR_ARTISTA="L'artista che si esibisce al concerto";
	public static final String TSHIRT="T-Shirt";
	private static final String DESCR_TSHIRT="Il prezzo dell'eventuale t-shirt acquistabile";
	public static final String PASS_BACKSTAGE="Pass Backstage";
	private static final String DESCR_PASS_BACKSTAGE="Il prezzo dell'eventuale pass backstage acquistabile";
	private static final String MSG_ARTISTA="Inserisci l'artista che si esibir� al concerto";
	private static final String MSG_COSTO="Inserisci il prezzo del campo "; 
	private Campo <String> artista=new Campo<>(ARTISTA, DESCR_ARTISTA, OBBLIGATORIO);
	private Campo <Double> tshirt=new Campo<>(TSHIRT, DESCR_TSHIRT, FACOLTATIVO);
	private Campo <Double> pass_backstage=new Campo<>(PASS_BACKSTAGE, DESCR_PASS_BACKSTAGE, FACOLTATIVO);
	private static final int MIN_COSTO=0;
	private static final String COSTI_AGGIUNTIVI="Possibili costi aggiuntivi";
	
	public Concerto() {
		super(NOME, DESCRIZIONE);
		addCampiConcerto();
	}
	
	public Concerto(int column) {
		super(column);
		addCampiConcerto();
		GestioneConcerto.inizializzaCampiDaFile(this);
	}
	
	public void addCampiConcerto() {
		addCampo(artista);
		addCampo(tshirt);
		addCampo(pass_backstage);
	}
	
	public ArrayList<Campo<Double>> pagabili(){
		ArrayList<Campo<Double>> pagabili=new ArrayList<>();
		pagabili.add(tshirt);
		pagabili.add(pass_backstage);
		return pagabili;
	}
	
	/*
	 * @see Evento#inizializza
	 */
	public void inizializza(Campo c, Utente u) {
		boolean pagabile=false;
		ArrayList<Campo<Double>> pagabili=pagabili();
		if(c.getNome().equals(ARTISTA)) {
			setArtista(InputDati.leggiStringaNonVuota(MSG_ARTISTA));
		}
		else {
			for(int i=0; i<pagabili.size(); i++) {
				if(c.getNome().equals(pagabili.get(i).getNome())) {
					pagabile=true;
				}
			}
			if(pagabile) {
				boolean ok=InputDati.yesOrNo(MESSAGGIO_FACOLTATIVO+c.getNome()+"?");
				if(ok) {
					setPagabile(c.getNome(), InputDati.leggiDoubleConMinimo(MSG_COSTO+c.getNome(), MIN_COSTO));
				}
			}
			else super.inizializza(c, u);
		}
	}
	
	/*
	 * @see Evento#addUtente
	 */
	public boolean addUtente(Utente u) {
		return GestioneConcerto.addUtente(u, this);
	}
	
	private void setArtista(String s) {
		setValCampo(ARTISTA, s);
	}
	
	public void setTshirt(double s) {
		setValCampo(TSHIRT, s);
	}
	
	public void setPass(double s) {
		setValCampo(PASS_BACKSTAGE, s);
	}
	
	private void setPagabile(String nome, double val) {
		if(nome.equals(TSHIRT)) setTshirt(val);
		else if(nome.equals(PASS_BACKSTAGE)) setPass(val);
	}
	
	public double getTshirt() {
		return tshirt.getValore();
	}
	
	public double getPass() {
		return pass_backstage.getValore();
	}
	
	public String getArtista() {
		return artista.getValore();
	}

	@Override
	public String mostraEv() {
		String s=Interfaces.mostraEvento(this);
		s+=COSTI_AGGIUNTIVI+"\n";
		if(getTshirt()!=0.0) s+="--"+Concerto.TSHIRT+": "+getTshirt()+"\n";
		if(getPass()!=0.0) s+="--"+Concerto.PASS_BACKSTAGE+": "+getPass()+"\n\n";
		s+=Concerto.ARTISTA+": "+getArtista()+"\n";
		return s;
	}

	
}
