package Eventi;

import java.io.File;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;

import GestioneExcell.ExcelReader;
import GestioneExcell.ExcelUtility;
import Stati.Aperto;
import Stati.State;
import Versione6.Utente;
import Versione6.Utility;

public class GestioneEvento {
	public static final int NUM_CAMPI=16;
	public static final int FIRST_PAGE=0;
	public static final int EVENT_NOME_ROW=0;
	public static final int EVENT_DESCRIZIONE_ROW=1;
	public static final int EVENT_STATO_ROW=2;
	public static final int EVENT_TITLE_ROW=3;
	public static final int EVENT_NUM_PART_ROW=4;
	public static final int EVENT_TERM_ISCR_ROW=5;
	public static final int EVENT_LUOGO_ROW=6;
	public static final int EVENT_DATA_IN_ROW=7;
	public static final int EVENT_ORA_IN_ROW=8;
	public static final int EVENT_DURATA_ROW=9;
	public static final int EVENT_QUOTA_ROW=10;
	public static final int EVENT_COMPRESO_QUOTA_ROW=11;
	public static final int EVENT_DATA_FIN_ROW=12;
	public static final int EVENT_ORA_FIN_ROW=13;
	public static final int EVENT_NOTE_ROW=14;
	public static final int EVENT_TOLLERANZA_PARTECIPANTI_ROW=15;
	public static final int EVENT_TERMINE_RITIRO_ISCR_ROW=16;
	private static final String FILE_EVENT="d:/Progetto Zanella/FileEventi/FileEventi.xlsx";
	public static final String FILE_UTENTI_EVENTI="d:/Progetto Zanella/FileEventi/FileUtentiEventi.xlsx";
	public static File FILE_UT_EV=new File(FILE_UTENTI_EVENTI);
	public static File FILE_EV=new File(FILE_EVENT);
		

	public static int getPartAtt(Evento e) {
		return getPartAtt(e, FILE_UT_EV);
	}
	
	public static int getPartAtt(Evento e, File f) {
		return ExcelReader.takeColumn(f, e.getColumn(), FIRST_PAGE).size();
	}
	
	public static void inizializzaCampiDaFile(Evento e) {
		ArrayList<String> colonna=ExcelReader.takeColumn(FILE_EV, e.getColumn(), FIRST_PAGE);
		if(!colonna.get(EVENT_TITLE_ROW).equals(ExcelReader.NO_VALUE)) e.setValCampo(Evento.TITOLO, colonna.get(EVENT_TITLE_ROW));
		e.setValCampo(Evento.NUM_PART, Integer.parseInt(colonna.get(EVENT_NUM_PART_ROW)));
		e.setValCampo(Evento.TERM_ULT_ISCR, mylib.Utility.StringToDate(colonna.get(EVENT_TERM_ISCR_ROW)));
		e.setValCampo(Evento.LUOGO, colonna.get(EVENT_LUOGO_ROW));
		e.setValCampo(Evento.DATA, mylib.Utility.StringToDate(colonna.get(EVENT_DATA_IN_ROW)));
		e.setValCampo(Evento.ORA, Time.valueOf(colonna.get(EVENT_ORA_IN_ROW)));
		if(!colonna.get(EVENT_DURATA_ROW).equals(ExcelReader.NO_VALUE)) {
			if(colonna.get(EVENT_DURATA_ROW).indexOf(":")==-1) {
				e.setValCampo(Evento.DURATA, Integer.parseInt(colonna.get(EVENT_DURATA_ROW)));
			}
			else e.setValCampo(Evento.DURATA, Time.valueOf(colonna.get(EVENT_DURATA_ROW)));
		}
		e.setValCampo(Evento.QUOTA, Double.parseDouble(colonna.get(EVENT_QUOTA_ROW)));
		if(!colonna.get(EVENT_COMPRESO_QUOTA_ROW).equals(ExcelReader.NO_VALUE))e.setValCampo(Evento.COMPRESO_QUOTA, colonna.get(EVENT_COMPRESO_QUOTA_ROW));
		if(!colonna.get(EVENT_DATA_FIN_ROW).equals(ExcelReader.NO_VALUE)) e.setValCampo(Evento.DATA_FIN, mylib.Utility.StringToDate(colonna.get(EVENT_DATA_FIN_ROW)));
		if(!colonna.get(EVENT_ORA_FIN_ROW).equals(ExcelReader.NO_VALUE)) e.setValCampo(Evento.ORA_FIN, Time.valueOf(colonna.get(EVENT_ORA_FIN_ROW)));
		if(!colonna.get(EVENT_NOTE_ROW).equals(ExcelReader.NO_VALUE)) e.setValCampo(Evento.NOTE, colonna.get(EVENT_NOTE_ROW));
		e.setValCampo(Evento.TOLLERANZA_PARTECIPANTI, Integer.parseInt(colonna.get(EVENT_TOLLERANZA_PARTECIPANTI_ROW)));
		e.setValCampo(Evento.TERMINE_RITIRO_ISCR,  mylib.Utility.StringToDate(colonna.get(EVENT_TERMINE_RITIRO_ISCR_ROW)));
	}
	
	public static void cambiaStato(State s, Evento e) {
		cambiaStato(s, e , FILE_EV);
	}
	
	public static void cambiaStato(State s, Evento e, File f) {
		e.setStato(s);
		ExcelReader.addToCell(s.getName(), f, e.getColumn(), EVENT_STATO_ROW, FIRST_PAGE);
	}
	
	public static void writeEvent(Evento e) {
		writeEvent(e, FILE_EV, FILE_UT_EV, ExcelUtility.FILE);
	}
	
	public static void writeEvent(Evento e, File f, File fue, File fu) {
		ArrayList<Campo> campi=e.getCampi();
		ExcelReader.addToColumn(e.getNome(), f, e.getColumn(), FIRST_PAGE);
		ExcelReader.addToColumn(e.getDescrizione(), f, e.getColumn(), FIRST_PAGE);
		ExcelReader.addToColumn(e.getStato().toString(), f, e.getColumn(), FIRST_PAGE);
		for(int i=0; i<campi.size(); i++) {
			Campo c =campi.get(i);
			if(!Utility.contenuto(Evento.CAMPI_DATE, c.getNome())) {
				if(c.getValore()==null) ExcelReader.addToColumn(ExcelReader.NO_VALUE, f, e.getColumn(), FIRST_PAGE);
				else ExcelReader.addToColumn(""+c.getValore(), f, e.getColumn(), FIRST_PAGE);
			}
			else ExcelReader.addToColumn(mylib.Utility.DateToString((Date)c.getValore()), f, e.getColumn(), FIRST_PAGE);
		}
		ArrayList<Utente> utenti=getUtenti(e, fue, fu);
		for(int i=0; i<utenti.size(); i++) {
			ExcelReader.addToColumn(utenti.get(i).getId(), fue, e.getColumn(), FIRST_PAGE);
		}
	}
	
	public static void ritiraEvento(Evento e) {
		Aperto.ritiraEvento(e);
	}
	
	public static void modificaStato(Evento e, File fue, File fe, File fu) {
		e.getStato().modificaStato(e, fue, fe, fu);
	}
	
	public static void modificaStato(Evento e) {
		e.getStato().modificaStato(e, FILE_UT_EV, FILE_EV, ExcelUtility.FILE);
	}
	
	public static boolean addUtente(Utente u, Evento e, File f) {
		ExcelReader.addToColumn(u.getId(), f, e.getColumn(), FIRST_PAGE);
		return true;
	}
	
	public static boolean addUtente(Utente u, Evento e) {
		return addUtente(u, e, FILE_UT_EV);
	}
	
	public static ArrayList<Utente> getUtenti(Evento e, File f, File fu) {
		ArrayList<String> strUtenti=ExcelReader.takeColumn(f, e.getColumn(), FIRST_PAGE);
		ArrayList<Utente> utenti=new ArrayList<>();
		for(int i=0; i<strUtenti.size(); i++) {
			utenti.add(ExcelUtility.takeUser(strUtenti.get(i), fu));
		}
		return utenti;
	}
	
	public static ArrayList<Utente> getUtenti(Evento e) {
		return getUtenti(e, FILE_UT_EV, ExcelUtility.FILE);
	}
	
	public static int getPartMax(Evento e) {
		return getPartMax(e, FILE_EV);
	}
	
	public static int getPartMax(Evento e, File f) {
		String num=ExcelReader.takeColumn(f, e.getColumn(), FIRST_PAGE).get(EVENT_TOLLERANZA_PARTECIPANTI_ROW);
		int toll=Integer.parseInt(num);
		int max=toll+getNumPart(e, f);
		return max;
	}
	
	public static int getNumPart(Evento e, File f) {
		String num=ExcelReader.takeColumn(f, e.getColumn(), FIRST_PAGE).get(EVENT_NUM_PART_ROW);
		return Integer.parseInt(num);
	}
	
	public static int getNumPart(Evento e) {
		return getNumPart(e, FILE_EV);
	}
	
	public static String getNome(int column) {
		return ExcelReader.takeColumn(FILE_EV, column, FIRST_PAGE).get(EVENT_NOME_ROW);
	}
	
	public static String getDescrizione(int column) {
		return ExcelReader.takeColumn(FILE_EV, column, FIRST_PAGE).get(EVENT_DESCRIZIONE_ROW);
	}
	
	public static State getStato (int column) {
		return Utility.riconosciStato(ExcelReader.takeColumn(FILE_EV, column, FIRST_PAGE).get(EVENT_STATO_ROW));
	}
}
