package Eventi;

public interface EventInterface {

	public String mostraEv();
}
