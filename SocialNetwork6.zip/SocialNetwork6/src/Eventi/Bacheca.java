package Eventi;

import java.util.ArrayList;

import GestioneExcell.ExcelUtility;
import Interfacce.Interfaces;

public class Bacheca {
	
	public static final int FIRST_PAGE=0;
	
	private static Bacheca instance;
	
	private Bacheca() {
	}
	
	public static synchronized Bacheca getInstance() {
		if(instance==null) {
			instance=new Bacheca();
		}
		return instance;
	}
	
	public ArrayList<String> mostraEventi(ArrayList<Integer> colonne) {
		ArrayList <String> result=new ArrayList<>();
		ArrayList <Evento> eventiAperti=ExcelUtility.eventiAperti();
		for(int i=0; i<eventiAperti.size(); i++) {
				colonne.add(eventiAperti.get(i).getColumn());
				result.add(eventiAperti.get(i).mostraEv());
		}
		return result;
	}
}
