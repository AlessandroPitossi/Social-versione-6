package Eventi;

import java.util.ArrayList;

import GestioneExcell.ExcelReader;
import Versione6.Utente;
import Versione6.Utility;

public class GestioneConcerto extends GestioneEvento{
	
	private static final int MIN_COSTO=0;

	public static final int EVENT_ARTISTA_ROW=NUM_CAMPI+1;
	public static final int EVENT_TSHIRT_ROW=NUM_CAMPI+2;
	public static final int EVENT_PASS_BACKSTAGE_ROW=NUM_CAMPI+3;
	private static final int SECOND_PAGE=1;

	public static void inizializzaCampiDaFile(Concerto c) {
		ArrayList<String> colonna=ExcelReader.takeColumn(FILE_EV, c.getColumn(), FIRST_PAGE);
		c.setValCampo(Concerto.ARTISTA, colonna.get(EVENT_ARTISTA_ROW));
		if(!colonna.get(EVENT_TSHIRT_ROW).equals(ExcelReader.NO_VALUE)) c.setValCampo(Concerto.TSHIRT, Double.parseDouble(colonna.get(EVENT_TSHIRT_ROW)));
		else c.setValCampo(Concerto.TSHIRT, (double)MIN_COSTO);
		if(!colonna.get(EVENT_PASS_BACKSTAGE_ROW).equals(ExcelReader.NO_VALUE)) c.setValCampo(Concerto.PASS_BACKSTAGE, Double.parseDouble(colonna.get(EVENT_PASS_BACKSTAGE_ROW)));
		else c.setValCampo(Concerto.PASS_BACKSTAGE, (double)MIN_COSTO);
	}
	
	public static boolean addUtente(Utente u, Concerto c) {
		String prezzi=Utility.consensi(c.pagabili());
		ExcelReader.addToColumn(prezzi, FILE_UT_EV, c.getColumn(), SECOND_PAGE);
		GestioneEvento.addUtente(u, c);
		return true;
	}
	
}
