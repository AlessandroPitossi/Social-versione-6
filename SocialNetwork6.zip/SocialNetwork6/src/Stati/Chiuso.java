package Stati;

import java.io.File;

import Eventi.Evento;
import Eventi.GestioneEvento;

public class Chiuso implements State{

	@Override
	public String getName() {
		return "CHIUSA";
	}

	@Override
	public void modificaStato(Evento e, File fue, File fe, File fu) {
		if(mylib.Utility.getTodayDate().after(e.getValueCampoDate(Evento.DATA_FIN))){
			GestioneEvento.cambiaStato(new Concluso(), e, fe);
		}
	}

}
