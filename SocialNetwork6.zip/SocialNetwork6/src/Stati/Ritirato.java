package Stati;

import java.io.File;

import Eventi.Evento;

public class Ritirato implements State{

	@Override
	public String getName() {
		return "RITIRATA";
	}

	@Override
	public void modificaStato(Evento e, File fue, File fe, File fu) {
	}

}
