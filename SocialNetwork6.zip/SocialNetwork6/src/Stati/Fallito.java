package Stati;

import java.io.File;

import Eventi.Evento;

public class Fallito implements State {

	@Override
	public String getName() {
		return "FALLITA";
	}

	@Override
	public void modificaStato(Evento e, File fue, File fe, File fu) {
	}

}
