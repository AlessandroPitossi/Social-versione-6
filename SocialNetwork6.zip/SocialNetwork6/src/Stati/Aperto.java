package Stati;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import Eventi.Evento;
import Eventi.GestioneEvento;
import GestioneExcell.ExcelUtility;
import Versione6.Utente;

public class Aperto implements State{


	@Override
	public String getName() {
		return "APERTA";
	}
	
	public static void ritiraEvento(Evento e) {
		GestioneEvento.cambiaStato(new Ritirato(), e);
		ExcelUtility.writeNotify(e);
	}

	@Override
	public void modificaStato(Evento e, File fue, File fe, File fu) {
		Date today=mylib.Utility.getTodayDate();
		ArrayList<Utente> utenti=GestioneEvento.getUtenti(e, fue, fu);
		if((utenti.size()>=GestioneEvento.getNumPart(e, fe)&&utenti.size()<=GestioneEvento.getPartMax(e, fe)&&today.after(e.getValueCampoDate(Evento.TERM_ULT_ISCR)))||
				(e.getValueCampoDate(Evento.TERMINE_RITIRO_ISCR).compareTo(today)<=0&&e.getValueCampoDate(Evento.TERM_ULT_ISCR).after(today)&&utenti.size()==GestioneEvento.getPartMax(e))) {
			GestioneEvento.cambiaStato(new Chiuso(), e, fe);
		}
		else {
			if(mylib.Utility.getTodayDate().compareTo(e.getValueCampoDate(Evento.TERM_ULT_ISCR))>=0){
				GestioneEvento.cambiaStato(new Fallito(), e, fe);
			}
		}
	}

}
