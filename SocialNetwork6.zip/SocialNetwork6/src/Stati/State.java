package Stati;

import java.io.File;

import Eventi.Evento;

public interface State {
	
	void modificaStato(Evento e, File fue, File fe, File fu);
	
	String getName();
}
